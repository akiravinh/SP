package com.vinh.pro01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
